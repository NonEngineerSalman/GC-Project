"""Backend package for the Website Carbon Footprint Checker project."""


