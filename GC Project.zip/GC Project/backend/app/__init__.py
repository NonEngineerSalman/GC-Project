"""Backend application package for Website Carbon Footprint Checker."""


