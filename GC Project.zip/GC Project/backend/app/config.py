"""Configuration constants and helper utilities for the analyzer service."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EnergyModel:
    """Parameters used to translate data transfer into carbon emissions."""

    energy_intensity_kwh_per_gb: float = 0.82
    carbon_intensity_kg_per_kwh: float = 0.475

    @property
    def carbon_grams_per_gb(self) -> float:
        """Return the grams of CO₂ emitted per gigabyte transferred."""

        return (
            self.energy_intensity_kwh_per_gb
            * self.carbon_intensity_kg_per_kwh
            * 1000.0
        )


ENERGY_MODEL = EnergyModel()


COMPARISON_DATA = {
    "lightweight_blog": {
        "label": "Lightweight Blog",
        "page_size_mb": 1.1,
        "requests": 35,
        "carbon_g": 0.43,
    },
    "corporate_site": {
        "label": "Corporate Landing Page",
        "page_size_mb": 2.6,
        "requests": 58,
        "carbon_g": 0.98,
    },
    "media_portal": {
        "label": "Media & Streaming Portal",
        "page_size_mb": 4.8,
        "requests": 95,
        "carbon_g": 1.85,
    },
    "ecommerce": {
        "label": "E-commerce Homepage",
        "page_size_mb": 3.7,
        "requests": 120,
        "carbon_g": 1.42,
    },
}


def determine_profile(page_size_mb: float, request_count: int) -> str:
    """Pick the closest comparison profile based on basic heuristics."""

    if page_size_mb <= 1.5 and request_count <= 45:
        return "lightweight_blog"
    if page_size_mb <= 3.2 and request_count <= 80:
        return "corporate_site"
    if page_size_mb >= 4.0 and request_count >= 90:
        return "media_portal"
    return "ecommerce"


