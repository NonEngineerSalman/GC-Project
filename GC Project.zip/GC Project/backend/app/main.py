"""Minimal HTTP server exposing the analyser via JSON endpoints."""

from __future__ import annotations

import json
from dataclasses import asdict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .analyzer import analyse_url


class CarbonHandler(BaseHTTPRequestHandler):
    server_version = "CarbonChecker/0.1"

    def _set_headers(self, *, status: int = HTTPStatus.OK, content_type: str = "application/json") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "content-type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self) -> None:  # noqa: N802 - method name constrained by BaseHTTPRequestHandler
        self._set_headers()

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._set_headers()
            self.wfile.write(json.dumps({"status": "ok"}).encode("utf-8"))
        else:
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/api/analyse":
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return

        length = int(self.headers.get("Content-Length", "0"))
        data = self.rfile.read(length)

        try:
            payload = json.loads(data.decode("utf-8"))
            url = payload.get("url")
            if not url:
                raise ValueError("Missing 'url' in payload")
            result = analyse_url(url)
            body = json.dumps(asdict(result), ensure_ascii=False).encode("utf-8")
            self._set_headers()
            self.wfile.write(body)
        except Exception as exc:  # pragma: no cover - defensive path
            self._set_headers(status=HTTPStatus.BAD_GATEWAY)
            error = json.dumps({"error": str(exc)}).encode("utf-8")
            self.wfile.write(error)


def create_server(host: str = "127.0.0.1", port: int = 8000) -> ThreadingHTTPServer:
    return ThreadingHTTPServer((host, port), CarbonHandler)



