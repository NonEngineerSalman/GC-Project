"""Core logic to inspect a website and derive sustainability metrics."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Iterable, List
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from .config import COMPARISON_DATA, ENERGY_MODEL, determine_profile
from .models import AnalysisResult, ComparisonItem, Suggestion

USER_AGENT = "CarbonChecker/1.0 (+https://example.com)"
READ_TIMEOUT = 15
MAX_RESOURCES = 60


@dataclass
class ResourceMetric:
    """Lightweight representation of a fetched resource."""

    url: str
    size_bytes: int
    kind: str


class _ResourceParser(HTMLParser):
    """HTML parser that extracts external resource references."""

    def __init__(self, base_url: str) -> None:
        super().__init__()
        self.base_url = base_url
        self.resources: list[tuple[str, str]] = []

    def handle_starttag(self, tag: str, attrs: Iterable[tuple[str, str | None]]) -> None:
        attr_map = {name: value for name, value in attrs if value}

        if tag == "img" and (src := attr_map.get("src")):
            self._append(src, "image")
        elif tag == "script" and (src := attr_map.get("src")):
            self._append(src, "script")
        elif tag == "link" and ("stylesheet" in (attr_map.get("rel", "") or "")):
            href = attr_map.get("href")
            if href:
                self._append(href, "stylesheet")
        elif tag == "video":
            src = attr_map.get("src") or attr_map.get("data-src")
            if src:
                self._append(src, "video")
        elif tag == "source" and (src := attr_map.get("src")):
            self._append(src, "media")

    def _append(self, raw_url: str, kind: str) -> None:
        if raw_url.startswith("data:"):
            return
        resolved = urljoin(self.base_url, raw_url)
        self.resources.append((resolved, kind))


def _extract_resources(html: str, base_url: str) -> List[tuple[str, str]]:
    parser = _ResourceParser(base_url)
    parser.feed(html)
    # Deduplicate while preserving order.
    seen: set[str] = set()
    unique: list[tuple[str, str]] = []
    for url, kind in parser.resources:
        if url not in seen:
            seen.add(url)
            unique.append((url, kind))
        if len(unique) >= MAX_RESOURCES:
            break
    return unique


def _generate_suggestions(
    *,
    page_size_mb: float,
    total_requests: int,
    image_requests: int,
    script_requests: int,
    stylesheet_requests: int,
) -> List[Suggestion]:
    """Produce actionable suggestions based on the metrics."""

    suggestions: list[Suggestion] = []

    if page_size_mb > 2.5:
        suggestions.append(
            Suggestion(
                title="Reduce overall page weight",
                description=(
                    "Your page is heavier than the typical low-carbon site."
                    " Consider compressing assets, lazy-loading below-the-fold content,"
                    " and removing unused dependencies."
                ),
            )
        )

    if image_requests > max(10, math.ceil(total_requests * 0.35)):
        suggestions.append(
            Suggestion(
                title="Optimise imagery",
                description=(
                    "High image density detected. Switch to next-gen formats (WebP/AVIF),"
                    " resize large media, and enable responsive loading attributes."
                ),
            )
        )

    if script_requests > 20:
        suggestions.append(
            Suggestion(
                title="Trim JavaScript bundles",
                description=(
                    "Many JavaScript files increase CPU and data use."
                    " Bundle strategically, remove unused scripts, and defer non-critical logic."
                ),
            )
        )

    if stylesheet_requests > 10:
        suggestions.append(
            Suggestion(
                title="Consolidate stylesheets",
                description=(
                    "Multiple CSS requests add latency. Combine styles, inline critical CSS,"
                    " and purge unused selectors to shrink downloads."
                ),
            )
        )

    if not suggestions:
        suggestions.append(
            Suggestion(
                title="Great job!",
                description=(
                    "Your page already performs efficiently. Keep monitoring emissions"
                    " as you ship new content to maintain a low footprint."
                ),
            )
        )

    return suggestions


def _build_comparisons(
    *, profile_key: str, page_size_mb: float, carbon_g: float
) -> List[ComparisonItem]:
    comparisons: list[ComparisonItem] = []
    for key, data in COMPARISON_DATA.items():
        delta_carbon = carbon_g - data["carbon_g"]
        delta_page_size = page_size_mb - data["page_size_mb"]
        comparisons.append(
            ComparisonItem(
                label=data["label"] + (" (closest)" if key == profile_key else ""),
                page_size_mb=data["page_size_mb"],
                requests=data["requests"],
                carbon_g=data["carbon_g"],
                delta_carbon_g=round(delta_carbon, 3),
                delta_page_size_mb=round(delta_page_size, 2),
            )
        )
    return comparisons


def _fetch(url: str, *, method: str = "GET"):
    request = Request(url, method=method, headers={"User-Agent": USER_AGENT})
    return urlopen(request, timeout=READ_TIMEOUT)


def _fetch_resource_size(url: str) -> int:
    try:
        with _fetch(url, method="HEAD") as response:
            length = response.headers.get("Content-Length")
            if length:
                return int(length)
    except (HTTPError, URLError, TimeoutError, ValueError):
        return 0
    except Exception:
        return 0
    return 0


def analyse_url(target_url: str) -> AnalysisResult:
    start = time.perf_counter()

    try:
        with _fetch(target_url) as response:
            html_bytes = response.read()
            final_url = response.geturl()
    except (HTTPError, URLError) as exc:
        raise RuntimeError(f"Failed to fetch {target_url}: {exc}") from exc

    load_time_ms = int((time.perf_counter() - start) * 1000)
    html = html_bytes.decode("utf-8", errors="ignore")

    resources = _extract_resources(html, final_url)

    total_size_bytes = len(html_bytes)
    image_requests = script_requests = stylesheet_requests = 0

    for url, kind in resources:
        size = _fetch_resource_size(url)
        total_size_bytes += size
        if kind == "image":
            image_requests += 1
        elif kind == "script":
            script_requests += 1
        elif kind == "stylesheet":
            stylesheet_requests += 1

    total_requests = 1 + len(resources)
    page_size_mb = round(total_size_bytes / (1024 * 1024), 3)

    data_gb = total_size_bytes / float(1024 ** 3)
    carbon_g = float(round(data_gb * ENERGY_MODEL.carbon_grams_per_gb, 3))
    energy_wh = float(round(data_gb * ENERGY_MODEL.energy_intensity_kwh_per_gb * 1000, 3))

    profile_key = determine_profile(page_size_mb, total_requests)

    suggestions = _generate_suggestions(
        page_size_mb=page_size_mb,
        total_requests=total_requests,
        image_requests=image_requests,
        script_requests=script_requests,
        stylesheet_requests=stylesheet_requests,
    )
    comparisons = _build_comparisons(
        profile_key=profile_key,
        page_size_mb=page_size_mb,
        carbon_g=carbon_g,
    )

    return AnalysisResult(
        url=final_url,
        total_requests=total_requests,
        total_size_bytes=total_size_bytes,
        page_size_mb=page_size_mb,
        image_requests=image_requests,
        script_requests=script_requests,
        stylesheet_requests=stylesheet_requests,
        carbon_emission_g=carbon_g,
        energy_consumption_wh=energy_wh,
        load_time_ms=load_time_ms,
        comparison_profile=COMPARISON_DATA[profile_key]["label"],
        comparisons=comparisons,
        suggestions=suggestions,
    )


