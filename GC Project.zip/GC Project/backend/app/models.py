"""Data models for serialising analysis results without third-party deps."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class AnalysisRequest:
    """Incoming payload for URL analysis."""

    url: str


@dataclass
class ComparisonItem:
    """Represents a benchmark used to contextualise a website."""

    label: str
    page_size_mb: float
    requests: int
    carbon_g: float
    delta_carbon_g: float
    delta_page_size_mb: float


@dataclass
class Suggestion:
    """Actionable tip returned to the caller."""

    title: str
    description: str


@dataclass
class AnalysisResult:
    """Response model returned to the UI."""

    url: str
    total_requests: int
    total_size_bytes: int
    page_size_mb: float
    image_requests: int
    script_requests: int
    stylesheet_requests: int
    carbon_emission_g: float
    energy_consumption_wh: float
    load_time_ms: int | None
    comparison_profile: str
    comparisons: List[ComparisonItem] = field(default_factory=list)
    suggestions: List[Suggestion] = field(default_factory=list)


