"""Run the carbon analysis HTTP server."""

from __future__ import annotations

from contextlib import suppress

from app.main import create_server


def main() -> None:
    server = create_server()
    host, port = server.server_address
    print(f"Serving carbon API on http://{host}:{port}")
    with suppress(KeyboardInterrupt):
        server.serve_forever()


if __name__ == "__main__":
    main()


