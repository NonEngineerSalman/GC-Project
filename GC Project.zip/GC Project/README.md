# Website Carbon Footprint Checker

Energy dashboard that estimates the environmental impact of any public webpage. Enter a URL, receive automated metrics (page weight, request count, resource mix) and estimated carbon emissions per visit, and compare the site against typical web profiles.

## Project layout

- `backend/` – pure-Python HTTP service exposing `/health` and `/api/analyse` endpoints
- `frontend/` – static dashboard (HTML/CSS/JS) powered by Chart.js
- `venv/` – optional virtual environment (not required because the backend only relies on the standard library)

## Getting started

1. **Start the backend**

   ```powershell
   cd "C:\Users\hp\Desktop\GC Project"
   python backend\run.py
   ```

   The service listens on `http://127.0.0.1:8000`. Keep the terminal open while analysing sites.

2. **Open the dashboard**

   Open `frontend/index.html` in any modern browser (double-click in Explorer or use `start ./frontend/index.html` from PowerShell).

3. **Analyse a website**

   Paste a full URL (including `https://`) and click **Analyse**. The dashboard will:

   - Fetch the page and its key resources
   - Estimate total data transfer and carbon emissions per visit
   - Suggest optimisation actions based on resource mix
   - Compare against typical site profiles (blog, corporate, media, e-commerce)

## Implementation notes

- The backend uses only the Python standard library (`urllib`, `html.parser`, `http.server`), so no package installation is required.
- Resource inspection is capped at 60 external assets and uses HTTP `HEAD` requests to estimate transfer sizes.
- Carbon estimates rely on the heuristics in `backend/app/config.py`. Adjust `EnergyModel` or `COMPARISON_DATA` to align with new research.
- Frontend visualisations are rendered with Chart.js via CDN; the page works offline after the first load if the CDN files are cached.

## Next ideas

- Cache previously analysed results to speed up repeated checks
- Add authentication and historical tracking for teams
- Integrate optional IoT or server telemetry for real-time energy data
- Enhance the comparison dataset with sector-specific baselines


