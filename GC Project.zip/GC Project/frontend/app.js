const API_BASE = "http://127.0.0.1:8000";

const form = document.getElementById("analyse-form");
const statusEl = document.getElementById("status");
const dashboard = document.getElementById("dashboard");

const resultUrlEl = document.getElementById("result-url");
const resultProfileEl = document.getElementById("result-profile");
const loadTimeEl = document.getElementById("load-time");

const carbonEl = document.getElementById("carbon");
const energyEl = document.getElementById("energy");
const pageSizeEl = document.getElementById("page-size");
const requestsEl = document.getElementById("requests");

const suggestionsList = document.getElementById("suggestions-list");
const comparisonBody = document.getElementById("comparison-body");

let resourceChart;
let benchmarkChart;

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const url = formData.get("url");

    if (!url) {
        return;
    }

    statusEl.textContent = "Analysing site… this may take a few seconds.";
    dashboard.hidden = true;

    try {
        const response = await fetch(`${API_BASE}/api/analyse`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url }),
        });

        if (!response.ok) {
            const message = await response.text();
            throw new Error(message || "Failed to analyse the site.");
        }

        const data = await response.json();
        renderDashboard(data);
        statusEl.textContent = "Analysis complete.";
    } catch (error) {
        console.error(error);
        statusEl.textContent = `We could not analyse this URL: ${error.message}`;
    }
});

function renderDashboard(data) {
    resultUrlEl.textContent = data.url;
    resultProfileEl.textContent = `Closest profile: ${data.comparison_profile}`;
    loadTimeEl.textContent = data.load_time_ms
        ? `${data.load_time_ms.toLocaleString()} ms to first render`
        : "Load time unavailable";

    carbonEl.textContent = `${data.carbon_emission_g.toFixed(3)}`;
    energyEl.textContent = `${data.energy_consumption_wh.toFixed(2)}`;
    pageSizeEl.textContent = `${data.page_size_mb.toFixed(2)}`;
    requestsEl.textContent = `${data.total_requests}`;

    renderSuggestions(data.suggestions);
    renderComparisons(data);
    renderResourceChart(data);
    renderBenchmarkChart(data);

    dashboard.hidden = false;
}

function renderSuggestions(suggestions) {
    suggestionsList.innerHTML = "";
    suggestions.forEach((suggestion) => {
        const li = document.createElement("li");
        const title = document.createElement("h4");
        title.textContent = suggestion.title;
        const description = document.createElement("p");
        description.textContent = suggestion.description;
        li.appendChild(title);
        li.appendChild(description);
        suggestionsList.appendChild(li);
    });
}

function renderComparisons(data) {
    comparisonBody.innerHTML = "";
    data.comparisons.forEach((item) => {
        const row = document.createElement("tr");
        if (item.label.includes("closest")) {
            row.classList.add("highlight");
        }

        row.appendChild(createCell(item.label));
        row.appendChild(createCell(`${item.page_size_mb.toFixed(2)} MB`));
        row.appendChild(createCell(`${item.requests}`));
        row.appendChild(createCell(`${item.carbon_g.toFixed(3)} g`));
        row.appendChild(createCell(formatDelta(item.delta_carbon_g, "g")));
        row.appendChild(createCell(formatDelta(item.delta_page_size_mb, "MB")));

        comparisonBody.appendChild(row);
    });
}

function renderResourceChart(data) {
    const otherRequests = Math.max(
        data.total_requests - (data.image_requests + data.script_requests + data.stylesheet_requests),
        0
    );

    const labels = ["Images", "Scripts", "Stylesheets", "Other"];
    const values = [data.image_requests, data.script_requests, data.stylesheet_requests, otherRequests];

    if (resourceChart) {
        resourceChart.destroy();
    }

    const context = document.getElementById("resource-chart");
    resourceChart = new Chart(context, {
        type: "doughnut",
        data: {
            labels,
            datasets: [
                {
                    label: "Requests",
                    data: values,
                    backgroundColor: [
                        "#38bdf8",
                        "#818cf8",
                        "#f472b6",
                        "#facc15",
                    ],
                },
            ],
        },
        options: {
            plugins: {
                legend: {
                    position: "bottom",
                    labels: { color: "#e2e8f0" },
                },
            },
        },
    });
}

function renderBenchmarkChart(data) {
    if (benchmarkChart) {
        benchmarkChart.destroy();
    }

    const labels = ["Carbon (g/visit)", "Page Size (MB)"];
    const actualValues = [data.carbon_emission_g, data.page_size_mb];

    let closest;
    for (const item of data.comparisons) {
        if (item.label.includes("closest")) {
            closest = item;
            break;
        }
    }
    const benchmarkValues = closest ? [closest.carbon_g, closest.page_size_mb] : [0, 0];

    const context = document.getElementById("benchmark-chart");
    benchmarkChart = new Chart(context, {
        type: "bar",
        data: {
            labels,
            datasets: [
                {
                    label: "Analysed site",
                    data: actualValues,
                    backgroundColor: "rgba(56, 189, 248, 0.7)",
                    borderColor: "#38bdf8",
                    borderWidth: 1,
                },
                {
                    label: closest ? closest.label.replace(" (closest)", "") : "Benchmark",
                    data: benchmarkValues,
                    backgroundColor: "rgba(129, 140, 248, 0.5)",
                    borderColor: "#818cf8",
                    borderWidth: 1,
                },
            ],
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    ticks: { color: "#cbd5f5" },
                    grid: { color: "rgba(148, 163, 184, 0.1)" },
                },
                y: {
                    ticks: { color: "#cbd5f5" },
                    grid: { color: "rgba(148, 163, 184, 0.1)" },
                },
            },
            plugins: {
                legend: {
                    labels: { color: "#e2e8f0" },
                },
            },
        },
    });
}

function createCell(text) {
    const td = document.createElement("td");
    td.textContent = text;
    return td;
}

function formatDelta(value, unit) {
    const fixed = value.toFixed(3);
    if (value > 0) {
        return `+${fixed} ${unit}`;
    }
    return `${fixed} ${unit}`;
}


